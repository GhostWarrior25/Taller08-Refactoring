/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.util.ArrayList;

/**
 *
 * @author jjmg0
 */
public class Calificaciones {
    Paralelo p;
    double nexamen;
    double ndeberes;
    double nlecciones;
    double ntalleres;

    public Paralelo getP() {
        return p;
    }

    public double getNexamen() {
        return nexamen;
    }

    public double getNdeberes() {
        return ndeberes;
    }

    public double getNlecciones() {
        return nlecciones;
    }

    public double getNtalleres() {
        return ntalleres;
    }
    
}

class CalculadoraNotas{
        public ArrayList<Paralelo> paralelos;
        public double CalcularNota(Calificaciones c){
        double notaInicial=0;
        for(Paralelo par:paralelos){
            if(c.getP().equals(par)){
                double notaTeorico=(c.getNexamen()+c.getNdeberes()+c.getNlecciones())*0.80;
                double notaPractico=(c.getNtalleres())*0.20;
                notaInicial=notaTeorico+notaPractico;
            }
        }
        return notaInicial;
    }
    
    
    //Calcula y devuelve la nota inicial contando examen, deberes, lecciones y talleres. Esta nota es solo el promedio de las dos calificaciones anteriores.
    public double CalcularNotaTotal(Calificaciones c){
        double notaTotal=0;
        for(Paralelo par:paralelos){
            if(c.getP().equals(par)){
                notaTotal=(c.getP().getMateria().notaInicial+c.getP().getMateria().notaFinal)/2;
                
            }
        }
        return notaTotal;
        
    }
}
